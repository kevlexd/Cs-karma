// ! Bu araç @Kraptor123 tarafından | @CS-Karma için yazılmıştır.
package com.kraptor

import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin
import android.content.Context

@CloudstreamPlugin
class NbaReplayPlugin: Plugin() {
    override fun load() {
        registerMainAPI(NbaReplay())
    }
}