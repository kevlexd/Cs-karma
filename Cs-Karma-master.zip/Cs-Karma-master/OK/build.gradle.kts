// ! Bu araç @ByAyzen tarafından | @cs-karma için yazılmıştır.
version = 1

cloudstream {
    authors     = listOf("ByAyzen")
    language    = "en"
    description = "OKRU Videos."
    status  = 1
    tvTypes = listOf("Movie", "TvSeries") //Movie, AnimeMovie, TvSeries, Cartoon, Anime, OVA, Torrent, Documentary, AsianDrama, Live, NSFW, Others, Music, AudioBook, CustomMedia, Audio, Podcast,
    iconUrl = "https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://ok.ru/video/c12842395&size=128"
}